/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Q1part2;

/**
 *
 * @author LENOVO
 */
public class loops {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i = 1;
        while(i<=0){
            System.out.println(i+". BEING RIGHT SUCKS");
            i++;
        }
        System.out.println("Value of i: "+i);
        System.out.println();
        
        int j = 1;
        do{
            System.out.println(j+". BEING RIGHT SUCKS");
            j++;
        }while(j<=0);
        System.out.println("Value of j: "+j);
        System.out.println();
        
        for(int k = 1; k <= 5; k++){
            if(k==3){
                break;
            }
            System.out.println(k+".BEING RIGHT SUCKS");
        }
        System.out.println();
        for(int k=1; k<=5; k++){
            for(int l = 1; l <= 2; l++){
                System.out.println("k=" + k + " l=" + l + " BEING RIGHT SUCKS");
            }
        }
        System.out.println();
    }
    
}
