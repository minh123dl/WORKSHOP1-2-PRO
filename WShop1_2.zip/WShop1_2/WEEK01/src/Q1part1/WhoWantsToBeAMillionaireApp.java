/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Q1part1;

/**
 *
 * @author LENOVO
 */
public class WhoWantsToBeAMillionaireApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        char answer = 'C';
        
        System.out.println("Who is named as the inventor of the light bulb?");
        System.out.println("You marked \" + answer + \". Let's see whether you are right!");
        
        if(answer == 'C'){
            System.out.println("You were right. You won $1.");
        }else {
            System.out.println("Sorry, the right answer is Tomas Edison. Thanks you for coming.");
            
        }
    }
    
}
