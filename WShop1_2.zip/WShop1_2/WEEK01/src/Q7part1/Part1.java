/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Q7part1;

import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class Part1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       int rows;
       int cols;
       int matrix[][];
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter number of rows: ");
       rows=sc.nextInt();
       System.out.println("Enter number of rows: ");
       cols=sc.nextInt();
       matrix=new int[rows][cols];
       System.out.println("Enter the matrix: ");
       for(int i=0; i<rows; i++){
           for(int j=0; j<cols; j++){
               System.out.println("\nm["+i+"] ["+j+"] =");
               matrix[i][j]=sc.nextInt();
           }
       }
        System.out.println("Matrix inputted: ");
        for(int i=0; i<rows; i++){
            for(int j=0; j<cols; j++){
                System.out.format("%3d", matrix[i][j]);
            }
            System.out.println("\n");
        }
        //SUM vs Average
        int sum=0;
        for (int i=0; i<rows; i++){
            for (int j=0; j<cols;j++){
                sum+=matrix[i][j];
            }
        }
        System.out.println("Sum:"+sum);
        System.out.println("Average:"+(float)sum/(rows*cols));
        }
    }
    

