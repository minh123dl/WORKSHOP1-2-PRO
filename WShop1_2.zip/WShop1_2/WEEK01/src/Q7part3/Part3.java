/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Q7part3;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author LENOVO
 */
public class Part3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<String> students = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of students:");
        int numStudents = scanner.nextInt();
        scanner.nextLine();  

        for (int i = 0; i < numStudents; i++) {
            System.out.println("Enter the name of student " + (i+1) + ":");
            String name = scanner.nextLine();
            students.add(name.toUpperCase());
        }

        System.out.println("The list of students in uppercase:");
        for (String name : students) {
            System.out.println(name);
        } 
    }
    
}
