/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Q4MenuDemo;
import java.util.Scanner;
/**
 *
 * @author LENOVO
 */
 public class Menu {
     public static Scanner in = new Scanner(System.in);
     public static int menu()
     {
         int choice;
         System.out.println("Press 1: ABC");
         System.out.println("Press 2: FVB");
         System.out.println("Press 3: exit");
         System.out.print("Enter your choice: ");
         choice = Menu.in.nextInt();
         return choice;
     }     
 }

