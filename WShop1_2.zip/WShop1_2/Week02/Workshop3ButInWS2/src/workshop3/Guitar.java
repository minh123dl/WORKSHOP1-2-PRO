/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package workshop3;

/**
 *
 * @author LENOVO
 */
public class Guitar {

    private String rerialNumber;
    private int price;
    private String builder;
    private String model;
    private String backWood;
    private String topWood;

    public Guitar(){
        
    }
    
    public Guitar(String rerialNumber, int price, String builder, String model, String backWood, String topWood) {
        this.rerialNumber = rerialNumber;
        this.price = price;
        this.builder = builder;
        this.model = model;
        this.backWood = backWood;
        this.topWood = topWood;
    }

    public String getRerialNumber() {
        return rerialNumber;
    }

    public void setRerialNumber(String rerialNumber) {
        this.rerialNumber = rerialNumber;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getBuilder() {
        return builder;
    }

    public void setBuilder(String builder) {
        this.builder = builder;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getBackWood() {
        return backWood;
    }

    public void setBackWood(String backWood) {
        this.backWood = backWood;
    }

    public String getTopWood() {
        return topWood;
    }

    public void setTopWood(String topWood) {
        this.topWood = topWood;
    }
    
    
    
    public void createSound(){
        System.out.println("Rerial Number: "+rerialNumber+"Price: "+price+"Builder: "+builder+"Model: "+model+"Back Wood: "+backWood+"Top Wood: "+topWood);
    }
}
