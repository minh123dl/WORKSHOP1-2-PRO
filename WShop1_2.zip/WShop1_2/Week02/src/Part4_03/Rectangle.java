/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part4_03;
import java.util.Scanner;
/**
 *
 * @author LENOVO
 */
public class Rectangle {
    private static Scanner sc = new Scanner(System.in);
    private float width;
    private float height;

    public Rectangle() {
    }

    public Rectangle(float width, float height) {
        this.width = width;
        this.height = height;
    }
    public float caculateArea(){
        return this.height*this.width;
    }
    public float caculatePerimeter(){
        return (this.height+this.height)/2;
    }

    @Override
    public String toString() {
        return "Rectangle{" + "width=" + width + ", height=" + height + '}';
    }
    
    public void input(){
        System.out.println("Enter Width: ");
        width = sc.nextFloat();
        System.out.println("Enter Height: ");
        height = sc.nextFloat();
    }
}
