/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part2_04;

/**
 *
 * @author LENOVO
 */
public class TestBookDemo {
    public static void main(String[] args) throws IllegalAccessException {
        Author ahTeck = new Author("Tan Ah Teck", "ahteck@nowhere.com", 'm');
        System.out.println(ahTeck);
        
        Book RoMinhBook = new Book("RoMinh", ahTeck, 19.95, 99);
        System.out.println(RoMinhBook);
        
        RoMinhBook.setPrice(29.95);
        RoMinhBook.setQty(28);
        System.out.println("name is: "+RoMinhBook.getName());
        System.out.println("price is: "+RoMinhBook.getPrice());
        System.out.println("qty is: "+ RoMinhBook.getQty());
        System.out.println("Author is: "+RoMinhBook.getAuthor());
        System.out.println("Author name is: "+RoMinhBook.getAuthor().getName());
        System.out.println("Author email is: "+RoMinhBook.getAuthor().getEmail());
        
        Book anotherBook = new Book("more Java", 
                new Author("Paul Tan", "paul@somewhere.com", 'm'), 19.95);
        System.out.println(anotherBook);
    }
}
