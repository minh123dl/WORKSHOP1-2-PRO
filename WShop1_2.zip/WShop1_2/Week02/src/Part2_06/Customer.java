/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part2_06;

/**
 *
 * @author LENOVO
 */
public class Customer {
    private int id;
    private String name;
    private char gender = 'o';

    public Customer(int id, String name, int discount) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public char getGender() {
        return gender;
    }

    @Override
    public String toString() {
        return "Name"+name+"(" + id + ')';
    }
    
    
}