/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part2_06;

/**
 *
 * @author LENOVO
 */
public class TestDemoAcc {
    public static void main(String[] args) {
         Customer c = new Customer(12, "Abache", 100000);
         Account a = new Account(113, c, 13.500);
         
         System.out.println(a);
         System.out.println(a.getCustomerName());
         
         a.deposit(10.000);
         System.out.println(a);
         
         a.withdraw(12.000);
         System.out.println(a);
    }
}
