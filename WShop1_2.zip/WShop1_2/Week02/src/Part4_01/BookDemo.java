/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part4_01;

/**
 *
 * @author LENOVO
 */
public class BookDemo {
    public static void main(String[] args) {
        Book book = new Book();
        Author author = new Author("Quynh Tran Ly");
        book.setAuthor(author);
        System.out.println(book);
        
        book.setTitle("Name hang");
        System.out.println(book);
        
        book.setFiction(true);
        
        book.setNiOfPages(1000);
        
        System.out.println(book);

    }
}
