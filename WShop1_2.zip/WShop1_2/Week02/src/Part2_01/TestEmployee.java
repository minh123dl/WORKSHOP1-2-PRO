/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part2_01;

/**
 *
 * @author LENOVO
 */
public class TestEmployee {
    public static void main(String[] args) {
        Employee e = new Employee(122, "Chi ", "Bet Ma", 2000);
        System.out.println(e.getName());
        System.out.println(e.getAnnualSalary());
        System.out.println(e.raiseSalary(20));
        System.out.println(e);
    }
}
