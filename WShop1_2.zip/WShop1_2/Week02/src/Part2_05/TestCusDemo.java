/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part2_05;

/**
 *
 * @author LENOVO
 */
public class TestCusDemo {
    public static void main(String[] args) {
        Customer c1 =new Customer(8, "Minh", 15000);
        Invoice i1 = new Invoice(1, c1, 1000000);
        
        System.out.println( i1.getCustomerName());
        System.out.println("Amount: "+i1.getAmountAfterDiscount());
        
    }
    
    
}
