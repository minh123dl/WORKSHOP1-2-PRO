/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part1;

/**
 *
 * @author LENOVO
 */
public class Tester {
    public static void main(String[] args){
        Car c=new Car();
        c.pressStartButton();
        c.pressAcceleratorButton();
        c.output();
        
        Car c2=new Car("red", 100, true, true);
        c2.pressStartButton();
        c2.setcolour("black");
        System.out.println("Colour of c2: "+ c2.getcolour());
        c2.output();
    }
    
}
