/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part1;

/**
 *
 * @author LENOVO
 */
public class Car {

    /**
     * @param args the command line arguments
     */
    private String colour;
    private int enginePower;
    private boolean converttible;
    private boolean parkingBreake;

    public Car() {
    }

    
    public Car(String colour, int enginePower, boolean converttible, boolean parkingBreake) {
        this.colour = colour;
        this.enginePower = enginePower;
        this.converttible = converttible;
        this.parkingBreake = parkingBreake;
    }

    public String getcolour() {
        return colour;
    }

    public void setcolour(String colour) {
        this.colour = colour;
    }

    public int getenginePower() {
        return enginePower;
    }

    public void setenginePower(int enginePower) {
        this.enginePower = enginePower;
    }

    public boolean isconverttible() {
        return converttible;
    }

    public void setconverttible(boolean converttible) {
        this.converttible = converttible;
    }

    public boolean isparkingBreake() {
        return parkingBreake;
    }

    public void setparkingBreake(boolean parkingBreake) {
        this.parkingBreake = parkingBreake;
    }
    
    public void pressStartButton(){
        System.out.println("You have pressed the start button");
    }
    
    public void pressAcceleratorButton(){
        System.out.println("You have pressed the Accelerator button");
    }
    
    public void output(){
        System.out.println("Colour: "+colour+"EnginePower: "+enginePower+"Convertible: "+converttible+"Parking Brake: "+parkingBreake);
    }
    
}
