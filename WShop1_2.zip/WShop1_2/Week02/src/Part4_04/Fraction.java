/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part4_04;

/**
 *
 * @author LENOVO
 */
public class Fraction {
    private int number;
    private int denom;

    public Fraction() {
    }

    public Fraction(int number, int denom) {
        this.number = number;
        this.denom = denom;
    }
    public void simplify(){
        int gcd = findGCD(number, denom);
        this.number /= gcd;
        this.denom /= gcd;
    }
    public int findGCD(int a, int b){
        int temp;
        while(b != 0){
            temp = b;
            b = a%b;
            a =temp;
        }
        return a;
    }

    public int getNumber() {
        return number;
    }

    public int getDenom() {
        return denom;
    }
    
    public Fraction add(Fraction x){
        Fraction result;
        
        if(denom == x.denom){
            result = new Fraction(x.number, denom);
        }else{
            int den = denom*x.getDenom();
            int num = number*x.getNumber();
            num += x.getNumber()*denom;
            num /= findGCD(num, den);
            den /= findGCD(num, den);
            result = new Fraction(num, den);
        }
        
        return result;
        
    }
    public Fraction subtract(Fraction x){
        Fraction result;
        
        if(denom == x.denom){
            result = new Fraction(x.number, denom);
        }else{
            int den = denom*x.getDenom();
            int num = number*x.getNumber();
            num -= x.getNumber()*denom;
            num /= findGCD(num, den);
            den /= findGCD(num, den);
            result = new Fraction(num, den);
        }
        return result;
    }
    public Fraction multiply(Fraction x){
        Fraction result;
        
        if(denom == x.denom){
            result = new Fraction(x.number, denom);
        }else{
            int den = denom*x.getDenom();
            int num = number*x.getNumber();
            num *= x.getNumber()*denom;
            num /= findGCD(num, den);
            den /= findGCD(num, den);
            result = new Fraction(num, den);
        }
        return result;
    }
    public Fraction divide(Fraction x){
        Fraction result;
        
        if(denom == x.denom){
            result = new Fraction(x.number, denom);
        }else{
            int den = denom*x.getDenom();
            int num = number*x.getNumber();
            num /= x.getNumber()*denom;
            num /= findGCD(num, den);
            den /= findGCD(num, den);
            result = new Fraction(num, den);
        }
        return result;
    }
    public boolean equals(Fraction x){
        boolean result = false;
        if (number == x.number && denom == x.denom) {
            result = true;
        }
        return result;
    }

    @Override
    public String toString() {
        return "Fraction{" + "number=" + number 
                + ", denom=" + denom + '}';
    }
    
}
