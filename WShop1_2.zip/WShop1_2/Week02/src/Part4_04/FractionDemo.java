/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part4_04;

/**
 *
 * @author LENOVO
 */
public class FractionDemo {
    public static void main(String[] args) {
        Fraction a = new Fraction(1, 3);
        Fraction b = new Fraction(3, 2);
        
        System.out.println(a);
        System.out.println(b);
        
        Fraction c = a.add(b);
        System.out.println(c.toString());
        
        c = a.subtract(b);
        System.out.println(c.toString());

        c = a.multiply(b);
        System.out.println(c.toString());
       
        c = a.divide(b);
        System.out.println(c.toString());
       
    }
}
