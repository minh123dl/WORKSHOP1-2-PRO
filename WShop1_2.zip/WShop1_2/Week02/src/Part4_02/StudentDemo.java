/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part4_02;

/**
 *
 * @author LENOVO
 */
public class StudentDemo {
    public static void main(String[] args) {
        Date dob = new Date(13, 10, 2);
        Student st = new Student("A", "1", dob, "Quang Trung", "Kidnap", 30.99);
        st.printAllAttributes();
    }
}
