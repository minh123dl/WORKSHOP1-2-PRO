/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part2_03;

/**
 *
 * @author LENOVO
 */
public class TestInvoiceItem {
    public static void main(String[] args) {
        InvoiceItem iv = new InvoiceItem("12B1", "Binh Chi", 1000, 12300);
        iv.getTotal();
        System.out.println(iv);
    }
}
