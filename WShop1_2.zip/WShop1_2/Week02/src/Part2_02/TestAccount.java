/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Part2_02;

/**
 *
 * @author LENOVO
 */
public class TestAccount {
    public static void main(String[] args) {        
        Account ac1 = new Account("12D", "Minh", 100000);
        Account ac2 = new Account("12B", "Mi");
        ac1.credit(10000);
        System.out.println(ac1);
        
        System.out.println("debit: "+ ac1.debit(20000));
        
        ac1.transferTo(ac2, 50000);
        
        System.out.println(ac1);
        System.out.println(ac2);

    }
}
